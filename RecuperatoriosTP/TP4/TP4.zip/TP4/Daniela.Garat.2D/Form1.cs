﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Entidades;
using System.IO;
using System.Data.SqlClient;


namespace Daniela.Garat._2D
{
    public partial class Form1 : Form
    {
        Correo mycorreo = new Correo();

        public Form1()
        {
            InitializeComponent();
            
        }

        private void btnAgregar_Click(object sender, EventArgs e)
        {
            Paquete nuevoPaquete = new Paquete(this.txtDireccion.Text, this.txtTrackingID.Text);
            nuevoPaquete.InformaEstado += paq_InformaEstado;
            try
            {
                this.ActualizarEstados();
                this.mycorreo = this.mycorreo + nuevoPaquete;
            }
            catch (TrackingIdRepetidoException tidEx)
            {
                MessageBox.Show(tidEx.Message, "Error");
            }
            catch (SqlException sEx)
            {
                MessageBox.Show(sEx.Message, "Error");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error");
            }
            
        }

        private void ActualizarEstados()
        {
            lst1.Items.Clear();
            lst2.Items.Clear();
            lst3.Items.Clear();

            foreach (Paquete paq in mycorreo.Paquetes)
            {
                switch (paq.Estado)
                {
                    case Paquete.EEstado.Ingresado:
                        lst1.Items.Add(paq);
                        break;

                    case Paquete.EEstado.EnViaje:
                        lst1.Items.Remove(paq);
                        lst2.Items.Add(paq);
                        break;

                    case Paquete.EEstado.Entregado:
                        lst2.Items.Remove(paq);
                        if (!lst3.Items.Contains(paq))
                        {
                            lst3.Items.Add(paq);
                        }
                        break;
                }
            }
        }

        private void paq_InformaEstado(object sender, EventArgs e)
        {
            if (this.InvokeRequired)
            {
                Paquete.DelegadoEstado d = new Paquete.DelegadoEstado(paq_InformaEstado);
                this.Invoke( d, new object[] {sender, e} );
            }
            else 
            {
                this.ActualizarEstados();
            }
        }

        private void MostrarInformacion<T>(IMostrar<T> elemento)
        {
            try
            {
                if (!object.ReferenceEquals(elemento, null))
                {
                    if (elemento is Paquete)
                    {
                        rtbMostrar.Text = ((Paquete)elemento).ToString();
                        rtbMostrar.Text.Guardar("salida.txt");
                    }
                    if (elemento is Correo)
                    {
                        rtbMostrar.Text = ((Correo)elemento).MostrarDatos((IMostrar<List<Paquete>>)elemento);
                        rtbMostrar.Text.Guardar("salida.txt");
                    }
                }
            }
            catch(FileNotFoundException fex)
            {
                MessageBox.Show("No se encontro el archivo:" + fex.Message);
            }
            catch(Exception ex)
            {
                MessageBox.Show("Error:" + ex.Message);
            }
            
        }

        private void Form1_FormClosing(object sender, EventArgs e)
        {
            mycorreo.FinEntregas();
        }


        private void btnMostrarTodos_Click(object sender, EventArgs e)
        {
            this.MostrarInformacion<List<Paquete>>((IMostrar<List<Paquete>>)mycorreo);
        }

        private void mostrarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            this.MostrarInformacion<Paquete>((IMostrar<Paquete>)lst3.SelectedItem);
        }
    }
}
