﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Entidades
{
    public static class PaqueteDAO
    {
        #region Atributos
        
        static private SqlCommand comando;
        static private SqlConnection conexion;
        
        #endregion

        #region Constructores

        static PaqueteDAO()
        {
            conexion = new SqlConnection(Entidades.Properties.Settings.Default.CadenaConexion);
            comando = new SqlCommand();
        }

        #endregion

        #region Metodos

        public static bool Insertar(Paquete p)
        {
            bool retorno = false;
            try
            {
                Paquete input = p;
                string query = String.Format("INSERT INTO Paquetes VALUES ('{0}','{1}','{2}')", p.DireccionEntrega, p.TrackingId, "Daniela Garat");
                comando.CommandText = query;
                
                comando.Connection = conexion;
                conexion.Open();
                comando.ExecuteNonQuery();
            }
            catch (SqlException sEx)
            {
                throw sEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                conexion.Close();
                retorno = true;
            }

            return retorno;
        }

        #endregion
    }
}
