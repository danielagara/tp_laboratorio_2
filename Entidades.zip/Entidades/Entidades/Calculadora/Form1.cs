﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using LibCalcu;


namespace LaCaluladora
{
    public partial class Form1 : Form
    {
       
        public Form1()
        {
            InitializeComponent();
        }

        private void btnLimpiar_Click(object sender, EventArgs e)//funciona limpiar
        {
            txtNumero1.Clear();
            txtNumero2.Clear();
            lblResultado.Text = "0" ;
            cmbOperador.Text = " " ;
            btnConvertirADecimal.Enabled = true;
            btnConvertirABinario.Enabled = true;
        }

        private void btnCerrar_Click(object sender, EventArgs e)//funciona cerrar
        {
            this.Close();
        }

        private void btnOperar_Click(object sender, EventArgs e)
        {
            btnConvertirADecimal.Enabled = false;
            Numero n1 = new Numero(txtNumero1.Text);
            Numero n2 = new Numero(txtNumero2.Text);
          
            MiCalculadora micalcu = new MiCalculadora();
            lblResultado.Text=micalcu.Operar(n1, n2, cmbOperador.Text).ToString();

        }

        private void btnConvertirABinario_Click(object sender, EventArgs e)
        {
            btnConvertirADecimal.Enabled = false;
            Numero decimalUsar =new Numero(lblResultado.Text);

            lblResultado.Text=decimalUsar.DecimalBinario(lblResultado.Text);
        }

        private void btnConvertirADecimal_Click(object sender, EventArgs e)
        {
            btnConvertirABinario.Enabled = false;
            Numero binarioUsar = new Numero(lblResultado.Text);

            lblResultado.Text = binarioUsar.BinarioDecimal(lblResultado.Text);
        }




    }
}
