﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace Entidades
{
    public class Paquete : IMostrar<Paquete>
    {
        #region Delegados y Eventos

        public delegate void DelegadoEstado(object sender, EventArgs e);
        public event DelegadoEstado InformaEstado;

        public delegate void DelegadoSQL(string mensaje);
        public event DelegadoSQL InformaExcepcion;

        #endregion

        #region Enum

        public enum EEstado
        {
            Ingresado=1,
            EnViaje=2,
            Entregado=3,
        }

        #endregion
        
        #region Atributos
        
        private string direccionEntrega;
        private EEstado estado;
        private string trackingID;

        #endregion

        #region Constructores
        
        public Paquete(string direccionEntrega, string trackingID)
        {
            this.direccionEntrega=direccionEntrega;
            this.trackingID=trackingID;
        }
        
        #endregion

        #region Propiedades

        public string DireccionEntrega
        {
            get
            {
                return this.direccionEntrega;
            }

            set
            {

                this.direccionEntrega=value;
            }
        }

        public EEstado Estado
        {
            get
            {
                return this.estado;
            }

            set
            {
                this.estado = value;
            }
        }
        
        public string TrackingId
        {
            get
            {
                return this.trackingID;
            }
            
            set
            {
                this.trackingID=value;
            }
        }

        #endregion

        #region Metodos

        public void MockCicloDeVida()
        {
            EventArgs myevent = new EventArgs();
            try
            {
                for (int i = 0; i < 3; i++)
                {
                    
                    switch (i)
                    {
                        case 0:
                            this.Estado = EEstado.Ingresado;
                            break;

                        case 1:
                            this.Estado = EEstado.EnViaje;
                            break;

                        case 2:
                            this.Estado = EEstado.Entregado;
                            break;
                    }
                    InformaEstado.Invoke(this, myevent);
                    System.Threading.Thread.Sleep(1000); 
                }
                PaqueteDAO.Insertar(this);
            }
            catch(SqlException sEx)
            {
                InformaExcepcion.Invoke(sEx.Message);
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public string MostrarDatos(IMostrar<Paquete> elemento)
        {
            string retorno = "";

            retorno= String.Format("{0} para {1}", ((Paquete)elemento).TrackingId, ((Paquete)elemento).DireccionEntrega);

            return retorno;
        }

        public static bool operator ==(Paquete paq1, Paquete paq2)
        {
            return (paq1.TrackingId == paq2.TrackingId);
        }

        public static bool operator !=(Paquete paq1, Paquete paq2)
        {
            return (!(paq1 == paq2));
        }

        public override string ToString()
        {
            return this.MostrarDatos((IMostrar<Paquete>)this);
        }


        #endregion


    }
}
