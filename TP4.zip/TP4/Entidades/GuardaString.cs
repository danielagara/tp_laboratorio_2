﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace Entidades
{
    public static class GuardaString
    {
        public static bool Guardar(this string texto, string archivo)
        {
            try
            {
                StreamWriter myStw = null;
                string rutaArchivo = Environment.GetFolderPath(Environment.SpecialFolder.Desktop);
                rutaArchivo += @"\" + archivo;
                myStw = new StreamWriter(rutaArchivo, File.Exists(rutaArchivo));
                myStw.WriteLine(texto);
                myStw.Close();
            }
            catch (FileNotFoundException fnfEx)
            {
                throw fnfEx;
            }
            catch (IOException ioEx)
            {

                throw ioEx;
            }
            catch (Exception ex)
            {
                throw ex;
            }     
            return true;
        }
    }
}
