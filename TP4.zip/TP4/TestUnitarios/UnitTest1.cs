﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Entidades;

namespace UnitTest
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void ValidaListaNotNull()
        {
            Correo myCorreo = new Correo();
            Assert.IsNotNull(myCorreo.Paquetes);
        }

        [TestMethod]
        public void ValidaTrackingIdRepetido()
        {
            Correo myCorreo = new Correo();
            Paquete paquete1 = new Paquete("111-111-1111", "asd 123");
            Paquete paquete2 = new Paquete("111-111-1111", "asd 123");

            myCorreo += paquete1;
            try
            {
                myCorreo += paquete2;
            }
            catch (Exception e)
            {

                Assert.IsInstanceOfType(e, typeof(TrackingIdRepetidoException));
            }
        }
    }
}
